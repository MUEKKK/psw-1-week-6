// Menunggu DOM selesai dimuat
const start = document.getElementById('START');

if (start) {
    start.addEventListener('click', function() {
        alert('mulai melihat web saya.');
    });
}

const terimaKasih = document.getElementById('terimakasih');

if (terimaKasih) {
    terimaKasih.addEventListener('click', function() {
        alert('Script PSWI Week 5 Sesi 3 berhasil dimuat.');
    });
}

const submit = document.getElementById('submit');

if (submit) {
    submit.addEventListener('click', function() {
        alert('FORMULIR TELAH TERKIRIM');
    });
}




